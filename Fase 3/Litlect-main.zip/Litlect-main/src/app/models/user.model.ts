export interface User{
    uid: string,
    email: string,
    password: string,
    name: string,
    image: string,
    role: string

}